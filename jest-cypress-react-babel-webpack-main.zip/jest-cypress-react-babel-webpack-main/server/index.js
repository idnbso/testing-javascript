const {start} = require('./src')

start()
