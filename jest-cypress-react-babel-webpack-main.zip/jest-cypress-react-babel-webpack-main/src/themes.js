export const dark = {
  displayTextColor: 'white',
  displayBackgroundColor: '#1c191c',
}

export const light = {
  displayTextColor: '#1c191c',
  displayBackgroundColor: 'white',
}
